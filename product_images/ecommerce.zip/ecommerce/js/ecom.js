$(document).ready(function() {
  var total = '';
  var itm = $("#item").text();
  var i = parseInt(itm, 10);
  i = i+1
  $(".item").load(location.href + " .item");  

//cart
	 	 $('.add').click(function add(e)
		 {
		 	e.preventDefault();
		 	var qty = $(this).closest('.product').find('.qty').val();
		 	var value = parseInt(qty, 10);
		 	value = isNaN(value) ? 0 : value;
		 	var pid = $(this).closest('.product').find('.id').val();
		 	var pcheck = $(this).closest('.product').find('.price').text();
		 	pcheck = isNaN(pcheck) ? 0 : pcheck;
		 	var total = ((pcheck) * (value));
        	$(this).attr('disabled', true);
        	$(this).closest('.product').find('.changeqty').remove();
		if (i <5 ) {
		$("#item").text((i++));
	}
	else{
		$(".msg").text('Item already exists in the cart');
	}
	 // $.ajax({
  //       type: "POST",
  //       url: "action.php",
  //       data: {
  //           pid: pid,
  //           tprice: total,
		// 	pty: qty,
		// 	action : 'insert'
  //       },
  //       dataType: 'JSON',
  //       success: function(data, response, xmlhttp) {

  //    },

  //       error: function(xhr, status, error) {
  //           console.error(status);
  //       }

  //   });
	
		 }
	 	);


	  $(document).on('click', '.inc', function valins() 
		 {
			var qty = $(this).closest('.prd-cart').find('.qty').val();
			var value = parseInt(qty, 10)
			//increment
			if (value < 10) 
				{
					value++;
					$(this).closest('.prd-cart').find('.qty').val(value);
					var qty = $(this).closest('.prd-cart').find('.qty').val();
					var value = parseInt(qty, 10);
					//price
					var price = $(this).closest('.prd-cart').find('.prd-price').text();
					var pcheck = parseInt(price, 10);
					var title = $('.item-name').text();
				        pcheck = isNaN(pcheck) ? 0 : pcheck;
						value = isNaN(value) ? 0 : value;
						total = ((pcheck) * (value));
					var totall = parseInt($('.totall').text());
					            $('.totall').text((totall)+(pcheck));	
				}
			//check
			pcheck = isNaN(pcheck) ? 0 : pcheck;
			value = isNaN(value) ? 0 : value;
			// $(this).closest('.prd-cart').find('.total').text(((pcheck) * (value)));
			if (value == 1) 
			               {
						    pcheck = pcheck * 2;
							total = ((pcheck) * (value));
							// $(this).closest('.prd-cart').find('.total').text(total);
							document.cookie = "totalp =" + total ;
							setCookie('qnty',value,3);
			                }
			else if (value > 1) 
				{
					// value = value + 1;
				    total = ((pcheck) * (value));
					$(this).closest('.prd-cart').find('.total').text(total);
				    setCookie("totalp", total, 3) ;
			    }
			    //update record
	      var iid = $(this).closest('.prd-cart').find('.id').val();
			$.ajax(
				{
				 url	:	"action.php",
				 method :   "POST",
				 data	:	{ 
							  	id: iid,
							  	tprice: total,
							  	qty: value,
							  	action: 'update', 
						    },
			      success	:	function(data)
			             { 
			             	setCookie('totalp',total,3);
                            window.locate.href= 'cart.php';
						 },

        error: function(xhr, status, error) {
            console.error(status);
        }
				});
	
		});
	//decre
	 $(document).on('click', '.less', function valdes() 
		 {
			var qty = $(this).closest('.prd-cart').find('.qty').val();
			var value = parseInt(qty, 10)
			value = isNaN(value) ? 0 : value;
			if ($('.add').attr('disabled', true)) {
	$(".msg").text('Item has been added in the cart changing of quantity here will cause any change in the cart');
}
				if (value > 1) 
					{
						value--;
						$(this).closest('.prd-cart').find('.qty').val(value);
								var qty = $(this).closest('.prd-cart').find('.qty').val();
								var value = parseInt(qty, 10)
								//price
								var price = $(this).closest('.prd-cart').find('.prd-price').text();
								var pcheck = parseInt(price, 10);
								var title = $('.item-name').text();
								//check
								pcheck = isNaN(pcheck) ? 0 : pcheck;
								value = isNaN(value) ? 0 : value;
								total = ((pcheck) * (value));
								var totall = parseInt($('.totall').text());
								$('.totall').text((totall)-(pcheck));
					}

			$(this).closest('.prd-cart').find('.total').text(total);
			setCookie('totalp', ((pcheck) * (value)) , 4);
			setCookie('qnty', value , 8);
		//update record
		    var iid = $(this).closest('.prd-cart').find('.id').val();
			$.ajax(
				{
				 url	:	"action.php",
				 method :   "POST",
				 data	:	{ 
							  	id: iid,
							  	tprice: total,
							  	qty: value,
							  	action: 'update', 
						    },
			      success	:	function(data)
			             { 
			             	setCookie('totalp',total,3);
			             	window.locate.href= 'cart.php';
						 },

        error: function(xhr, status, error) {
            console.error(status);
        }
				});

		});

	 $('.remove').click(function rem(e)
		 {

            $(this).closest('.prd-cart').remove();
			var qty = $(this).closest('.prd-cart').find('.qty').val();
			var value = parseInt(qty, 10);
			var price = $(this).closest('.prd-cart').find('.prd-price').text();
			var pcheck = parseInt(price, 10);
			total = ((pcheck) * (value));
			var totall = parseInt($('.totall').text());
			$('.totall').text((totall)-(total));
            // alert();
            var iid = $(this).closest('.prd-cart').find('.id').val();
  		 	// e.preventDefault();
			$.ajax(
				{
				 url	:	"action.php",
				 method :   "POST",
				 data	:	{ 
							  	id: iid,
							  	action: 'remove', 
						    },
			      success	:	function(data)
			             { 
			             eraseCookie('totalp');
			             eraseCookie('qnty');
			             window.location.href;
						 },

        error: function(xhr, status, error) {
            console.error(status);
        }
				});
	
		 }
	 	);
$('.items').click(function order(e){
window.location.href ='cart.php';
});
  // checkout
// 	 $('.chkout').click(function (e)
// 		 {
// 		 	e.preventDefault();
// 		 	//cart
// 		 	var qty = $(this).closest('.checkout').find('.chkqty').text();
// 		 	var value = parseInt(qty, 10);
// 		 	    value = isNaN(value) ? 0 : value;
// 		 	var title = $(this).closest('.checkout').find('.chktitle').text();
// 		 	var pid = $(this).closest('.product').find('.id').text();
// 		 	var tprice = $(this).closest('.checkout').find('.chktprice').text();
// //input
// 		 	var name = $('.chkfname').val() +' '+ $('.chklname').val();
// 		 	var email = $('.chkemail').val();
// 		 	var address = $('.chkaddress').val();
// 		 	var pay_type = 'Cash on Delivery';
// 		 	var order_sts = 0;
// 		 	var total = $('.total').text();
// 	 $.ajax({
//         type: "POST",
//         url: "action.php",
//         data: {
//             name: name,
//             email: email,
// 			address: address,
// 			total: total,
// 		    action: 'chkord',
//         },
//         dataType: 'JSON',
//         success: function(data, response, xmlhttp) {
//         	window.location.href = "cart.php";
//         	// alert(data);
//         },

//         error: function(xhr, status, error) {
//             console.error(xhr);
//         }

//     });
	
// 		 }
// 	 	);

	 	 $('.date').click(function (e)
		 {
		 	// e.preventDefault();
		 	var oid = $(this).closest('.ord-det').find('.ord-id').text();
            var ord_id = parseInt(oid, 10);
		 	    ord_id = isNaN(ord_id) ? 0 : ord_id;
		 	    $.ajax({
        type: "POST",
        data: {
            ord_id: ord_id,
		    action: "ord_det",
        },
        url: "order_details.php",
        success: function(data, response, xmlhttp) {
        window.location.href="?order_details";        },

        error: function(xhr, status, error) {
            console.error(xhr);
        }

    });
		 });

		 $('.status').change(function (e)
		 {
		 	// e.preventDefault();
		 	var oid = $(this).closest('.ord-det').find('.ord-id').text();
            var ord_id = parseInt(oid, 10);
		 	    ord_id = isNaN(ord_id) ? 0 : ord_id;
		    var status = $(this).val();
		 	    $.ajax({
        type: "POST",
        data: {
            ord_id: ord_id,
            status: status,
		    action: "sts_upd",
        },
        url: "action.php",
        success: function(data, response, xmlhttp) {
        window.location.href('admin.php');
             },

        error: function(xhr, status, error) {
            console.error(xhr);
        }

    });
		 });

});