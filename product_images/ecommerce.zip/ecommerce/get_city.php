<?php
    $curl = curl_init();
        $where = urlencode('{
            "updatedAt": {
                "$exists": true
            }
        }');
    curl_setopt($curl, CURLOPT_URL, 'https://parseapi.back4app.com/classes/Pakistancities_City?&order=name,location,createdAt&where=' . $where);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'X-Parse-Application-Id: oXEGghDoQ2bkyBgT0iie3vKIwBKKQXeWu4unPfvP', // This is your app's application id
        'X-Parse-REST-API-Key: WWGfTzixAWoiasXq0HzvOy6SG1r15PzqgBGMI7KM' // This is your app's REST API key
    ));
    $data = json_decode(curl_exec($curl)); // Here you have the data that you need
    // print_r(json_encode($data, JSON_PRETTY_PRINT));
    curl_close($curl);
    echo "<pre>";
print_r($data);
?>