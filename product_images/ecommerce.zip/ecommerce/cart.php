<?php 
require_once("config.php");
$file =  basename(__FILE__, '.php');
require('head.php');
require('inc.php');	
$msg ='';
?>


	<div class="table-responsive">
		<form method="POST">
			<table class="table table-bordered">
				<tr><th width="20%">Image</th>
					<th width="30%">Product Name</th>
					<th width="13%">Quantity</th>
					<th width="13%">Price Details</th>
					<th width="15%">Total Price</th>
					<th width="20%">Remove Item</th>
				</tr>

          
				<?php if (isset($_COOKIE['shopping_cart'])) {
						$Total = 0;
						$cookie_data = stripcslashes($_COOKIE['shopping_cart']);
						$cart_data = json_decode($cookie_data, true);
						foreach ($cart_data as $key => $cart_item) {
						?>
						<tr class='prd-cart'>
							<td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$cart_item['image']; ?>" alt="image"></td>
							<td class="item-name"> <?php echo $cart_item['item_name']; ?></td>
							<td>
								<div class="input-group">
									<span class="input-group-addon changeqty less" name="less"><b>-</b></span>
									<input type="text" disabled="true" name="qty" class="qty form-control text=center" value="<?php echo $cart_item['qty']; ?>">
									<span class="input-group-addon changeqty inc"><b>+</b></span>
								</div>
								<input class="qt" type="hidden" name="qty">
								<input type="hidden" class="id" value="<?php echo $cart_item['item_id']; ?>">	
							</td>
							<td class="prd-price"><?php $cart_item['price'];  echo $cart_item['price']; ?></td>
							<td class="total">$ <?php 
							// $title = $cart_item['title'];
							 echo number_format($cart_item['price'] * $cart_item['qty'],2); ?></td>
							<td><a class="text-danger" href="?action=delete&id=<?php echo $cart_item['item_id']; ?>">Remove Item</a></td>
						</tr>
						<?php
						$Total = $Total+($cart_item['qty'] * $cart_item['price']);
					}
					?>
					<tr><td></td><td colspan="3" align="right">Total</td>
						<td class="totall" align="right" class="text-center">$ <?php echo number_format($Total, 2); ?> </td>
						<td class="totall" align="right" class="text-center"><a href="?action=clear">Clear Cart</a> </td>
					</tr>

					<?php	
				} 
				else
				{
					$msg = '<center><img src="https://media1.giphy.com/media/CcWVv13k8mA796x7o0/giphy.gif?cid=6c09b9521sewozng4viysn9301u6n3du2ikdqkpbi3anxcno&rid=giphy.gif&ct=s" alt="cart is empty"></center>';
				}
				?>
			</table>
<?php echo $msg; ?>
			<form>
			</div>
		</div>
		</body>
		</html>