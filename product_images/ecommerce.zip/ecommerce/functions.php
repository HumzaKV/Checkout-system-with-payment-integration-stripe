<?php 
function qty()
{
$_SESSION['qnty'] = $_POST['qty'];
}	 

function chopExtension($filename) {
    return pathinfo($filename, PATHINFO_FILENAME);
}

function alert($msg)
{
	echo "<script>alert('".$msg."');</script>";
}

?>