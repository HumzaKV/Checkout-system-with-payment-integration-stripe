<?php 
require_once('config.php');
 if(isset($_POST['action']) && $_POST['action'] == 'update')
	 {
		$id = mysqli_real_escape_string($conn, $_POST['id']);
 	    $tprice = mysqli_real_escape_string($conn, $_POST['tprice']);
 	    $pty = $_POST['qty']; 	  
	    if(mysqli_query($conn, "UPDATE cart set `tprice` = '$tprice', `qty` = '$pty' WHERE id = '$id'")) {
	    	echo "updated";
	    } 
		    else 
		    {
		       echo "Error: " . mysqli_error($conn);
		    }
	 }

 if(isset($_POST['action']) && $_POST['action'] == 'insert')
  	{
 	    $id = mysqli_real_escape_string($conn, $_POST['pid']);
 	    $tprice = mysqli_real_escape_string($conn, $_POST['tprice']);
 	    $pty = $_POST['pty']; 	 
	    if(mysqli_query($conn, "INSERT INTO cart (`id`,`tprice`, `qty`) VALUES('$id','$tprice','$pty')")) {
	    	echo "Added";
	    } 
		    else 
			    {
			       echo "Error: " . mysqli_error($conn);
			    }
    }

 if(isset($_POST['action']) && $_POST['action'] == 'remove')
  	{
  		$id = mysqli_real_escape_string($conn, $_POST['id']);
	    if(mysqli_query($conn, "DELETE FROM `cart` WHERE id = '$id'")) 
	    {
	    	echo "deleted";
	    } 
		    else 
		    {
		       echo "Error: " . mysqli_error($conn);
		    }
    }
 if(isset($_POST['action']) && $_POST['action'] == 'chkord')
  	{

 	    $name    = mysqli_real_escape_string($conn, $_POST['name']);
 	    $email   = mysqli_real_escape_string($conn, $_POST['email']);
 	    $total   = mysqli_real_escape_string($conn, $_POST['total']);
 	    $address = $_POST['address']; 	 
	    if(mysqli_query($conn, "INSERT INTO `orderr` (`name`,`total_price`,`email`, `address`,`payment_type`,`added_on`,`order_status`) VALUES('$name','$total','$email','$address','Cash on Delivery',NOW(),'0')")) {
	    	echo $_SESSION['ord_id'] = mysqli_insert_id($conn);
            mysqli_query($conn, "TRUNCATE cart");
            // session_unset($_SESSION['cart']);
	    } 
		    else 
			    {
			       echo "Error: " . mysqli_error($conn);
			    }
    }
     if(isset($_POST['action']) && $_POST['action'] == 'sts_upd')
  	{
 	    $ord_id    = mysqli_real_escape_string($conn, $_POST['ord_id']);
 	    $status    = mysqli_real_escape_string($conn, $_POST['status']);
	    if(mysqli_query($conn, "UPDATE `orderr` SET `order_status`= '$status' WHERE ord_id = $ord_id")) {
	    } 
		    else 
			    {
			       echo "Error: " . mysqli_error($conn);
			    }
    }
?>