<?php 
if (isset($_GET['action'])) {
if ($_GET['action'] == "delete") 
{
	$cookie_data = stripcslashes($_COOKIE["shopping_cart"]);
    $cart_data = json_decode($cookie_data, true);
    foreach ($cart_data as $key => $value) {
    	if ($cart_data[$key]['item_id'] == $_GET['id']) {
    		unset($cart_data[$key]);
    		$item_data = json_encode($cart_data);
    		setcookie('shopping_cart', $item_data, time() + (86400 * 30));
header("Refresh:0");
    	}
    }
}
elseif ($_GET['action'] == "clear") {
	setcookie('shopping_cart','',time() - 3600);
	header('location:index.php');
}
}
 ?>