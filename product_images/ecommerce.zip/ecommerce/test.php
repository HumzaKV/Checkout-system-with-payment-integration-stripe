<form class="card p-2" method="POST">
              <div class="input-group">
                <!-- <input type="text" disabled="true" class="form-control" placeholder="Promo code"> -->
                <label class="form-control" for="credit">Cash On Delivery</label>
                <div class="input-group-append">
                  <input type="submit" name="order" class="btn btn-primary chkout" value="Place Order">
                </div>
              </div>
              <span class="id"></span>
            </form>
            <?php  ?>