<?php

require_once("config.php");
$sql = "SELECT * FROM product ORDER BY id ASC";
$feature = $conn->query($sql);
$file =  basename(__FILE__, '.php');
require('head.php');

if (isset($_POST['add'])) {
	if (isset($_COOKIE['shopping_cart'])) {
		$cookie_data = stripcslashes($_COOKIE['shopping_cart']);
		$cart_data = json_decode($cookie_data, true);
	}
	else{
		$cart_data = array();
	}
	$item_array_id = array_column($cart_data, 'item_id');
	if (in_array($_POST['pid'], $item_array_id)) {
		foreach ($cart_data as $key => $value) {
			if ($cart_data[$key]["item_id"] == $_POST['pid']) {
				// $cart_data[$key]['qty'] = $cart_data[$key]['qty'] + $_POST['qty'];
				echo "item already exists";
			}
		}
	}
	else{
	$item_array = array(
		'item_id' => $_POST['pid'],
		'item_name' => $_POST['hidden_name'],
		'image' => $_POST['img'],
		'price' => $_POST['hidden_price'],
		'qty' => $_POST['item-qty'],
		 );
	$cart_data[] = $item_array;
if ($cunt == 0) {
	$cunt = 1;
}
else{
	$cunt = $cunt++;
}
	
	}
	// $item_array = array(
	// 	'item_id' => $_POST['pid'],
	// 	'qty' => $_POST['item-qty'],
	// 	'item_name' => $_POST['hidden_name'],
	// 	'image' => $_POST['img'],
	// 	'price' => $_POST['hidden_price'],
	// 	 );
	// $cart_data[] = $item_array;
	$item_data = json_encode($cart_data);
	setcookie('shopping_cart',$item_data,time() + (86400 * 30));
	// header("location:?success=1");
}
if (isset($_GET['success'])) {
	echo 'Success added to cart';
}
?>
<body>
		<div class="row">
					<?php 
if (mysqli_num_rows($feature) > 0) {
					while ($product = mysqli_fetch_assoc($feature))
					{
						$cid = $product['id'];
						$query = "SELECT * FROM cart WHERE `id` = '$cid'";
                        $cart = $conn->query($query);
                        $count = mysqli_num_rows($cart);
					 ?>
					 	<div class="col-md-3">
						<form method="POST">
		 					<div class="product prd-cart">
		 						<img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$product['image']; ?>" alt="hello" class="img-responsive pic">
					 			<h5 class="text-info"><?php echo $product['title']; ?></h5>
					 		    <h5 class="text-danger">Rs:<span class="price"><?php echo $product['price']; ?></span></h5>
					 		    <input type="hidden" name="item-qty" class="qty form-control text=center" value="1">
					 		    <input type="hidden" name="img" value="<?php echo PRODUCT_IMAGE_SITE_PATH.$product['image']; ?>">
                                <input type="hidden" name="pid" class="id" value="<?php echo $product['id']; ?>">
					 		    <?php 
					 		    if ($check = mysqli_fetch_assoc($cart)) { ?>
					 		    	<div class="input-group">
									<input type="text" disabled="true" name="qty" class="qty form-control text=center" value="<?php echo $check['qty'] ?>">
								</div>
                                <input type="text" name="item-qty" class="qty" value="1">
					 		    <input type="hidden" name="hidden_name" value="<?php echo $product['title']; ?>">
					 		    <input type="hidden" name="hidden_price" value="<?php echo $product['price']; ?>">
					 		    
							    <input type="submit" name="add" value="Add to cart" style="        margin-top: 5px;" disabled class=" btn btn-success">
					 		   <?php } 
					 		   else
					 		   	{?>
                                    <div class="input-group">
									<span class="input-group-addon changeqty less" name="less"><b>-</b></span>
									<input type="text" disabled="true" name="item-qty" class="qty form-control text=center" value="1">
									<span class="input-group-addon changeqty inc"><b>+</b></span>
								</div>
								<input type="hidden" name="hidden_name" value="<?php echo $product['title']; ?>">
					 		    <input type="hidden" name="hidden_price" value="<?php echo $product['price']; ?>">
					 		    <input type="hidden" name="pid" class="id" value="<?php echo $product['id']; ?>">
							    <input type="submit" name="add" value="Add to cart" style="        margin-top: 5px;" class=" btn btn-success">
					 		   	<?php } ?>
					 		    
					 		    
					 		</div>
					 	</form>
	</div>
	
<?php 
}
} 

?>
</div>
</div>
</body>
</html>