		<?php 
require('functions.php');
		ob_start();
		$msg = '';
if (empty($cunt)) {
	$cunt = 0;
}
		?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Ecommerce | <?php echo $file; ?></title>
	<link rel="stylesheet" href="css\style.css">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<!-- <script src="main.js"></script> -->
	<link rel="stylesheet" href="css/demo.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.js" 
	integrity=
	"sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" 
	crossorigin="anonymous">
    </script>
	<script src="js\ecom.js"></script>
	<script src="js\function.js"></script>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
	<div class="container">
		<?php echo $msg; ?>
		<h2><?php if ($file == 'cart') { ?>
<span class="badge badge-secondary badge-pill"><a href="index.php" class="text-white"> <i class="glyphicon glyphicon-arrow-left text-white"></i> Products</a></span>
<?php }?> &nbsp; <?php echo $file ?> &nbsp;
          <?php if ($file == 'cart') { ?>
<span class="badge badge-secondary badge-pill"><a href="checkout.php" class="text-white"> Proceed to checkout <i class="glyphicon glyphicon-arrow-right text-white"></i></a></span>
<?php }
else{ ?>
          <span class="items badge badge-secondary badge-pill">Your cart: <span id="item" class="item"><?php echo $cunt; ?></span></span>
          <p class="msg text-danger fs-4"></p>
<?php } 
?>
      </h2>
