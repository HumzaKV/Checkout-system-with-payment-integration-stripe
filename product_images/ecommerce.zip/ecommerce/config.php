<?php 
$conn= mysqli_connect('localhost','root','','sample');
if ($conn) {
}
else if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
function get_data($str)
{
	if (!empty($str)) {
	mysqli_real_escape_string($conn,$str);
}
}
session_start();
define('SERVER_PATH', $_SERVER['DOCUMENT_ROOT'].'/hamza/ecommerce/');
define('SITE_PATH', 'http://127.0.0.1/hamza/ecommerce/');

define('PRODUCT_IMAGE_SERVER_PATH', SERVER_PATH.'product_images/');
define('PRODUCT_IMAGE_SITE_PATH', SITE_PATH.'product_images/');
?>