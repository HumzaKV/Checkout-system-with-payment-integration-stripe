<?php 
require_once('config.php');
$file =  basename(__FILE__, '.php');
require_once('head.php');
require('inc.php'); 
$ins = mysqli_query($conn,"SELECT * FROM cart");
$vr = mysqli_num_rows($ins);
$Total = 0;
$msg = '';
?>
<body>
 <main>

   <!-- DEMO HTML -->
    <div class="row">
      <div class="col-md-4 order-md-2 mb-4">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-muted">Your cart</span>
          <span class="badge badge-secondary badge-pill"><?php echo $cunt; ?></span>
        </h4>
        <ul class="list-group mb-3 checkout prd-cart">
         <?php if (isset($_COOKIE['shopping_cart'])) {
            $Total = 0;
            $cookie_data = stripcslashes($_COOKIE['shopping_cart']);
            $cart_data = json_decode($cookie_data, true);
            foreach ($cart_data as $key => $cart_item) {
            ?>
              <li class="list-group-item d-flex justify-content-between lh-condensed">
                <div>
                  <h6 class="my-0 chktitle"><?php echo $cart_item['item_name']; ?></h6>
                  qty: <small class="text-muted chkqty"><?php echo $cart_item['qty']; ?></small>
                </div>
                <span class="text-muted chktprice">$<?php echo $cart_item['qty'] * $cart_item['price']; ?></span><a href="?action=delete&id=<?php echo $cart_item['item_id']; ?>"><span class="glyphicon glyphicon-trash remove"></span></a>
                <input type="hidden" class="id" value="<?php echo $cart_item['item_id'];?>">
              </li>
              <?php
              $Total = $Total+($cart_item['qty'] * $cart_item['price']); 
            }
          }
          else{
            header('location:index.php');
            die();
          } ?>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <span class="my-0"><strong>Total ($)</strong></h6>
              </div>
              <span class="text-muted total">$ <?php echo number_format($Total, 2); ?></span>
            </li>
          </ul>
                    

        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Billing address</h4>
          <form class="needs-validation" method="POST">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control chkfname" name="chkfname" id="firstName" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid first name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control chklname" name="chklname" id="lastName" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid last name is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Email <span class="text-muted">(Optional)</span></label>
              <input type="email" class="form-control chkemail" name="chkemail" id="email" placeholder="you@example.com">
              <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div>
            </div>

            <div class="mb-3">
              <label for="address">Address</label>
              <input type="text" class="form-control chkaddress" name="chkaddress" id="address" placeholder="1234 Main St" required>
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>
            <hr class="mb-4">
              <div class="input-group">
                <label for="credit">Cash On Delivery</label>
                <div class="input-group-append">
                  <input type="submit" name="order" class="btn btn-primary chkout" value="Place Order">
                </div>
              </div>
              <span class="id"></span>
          </form>
        </div>
      </div>

    </div>
    <!-- End Demo HTML -->
  </main>
  

          <?php        if (isset($_POST['order'])) {
$name = $_POST['chkfname'].' '.$_POST['chklname'];
$email = $_POST['chkemail'];
$address = $_POST['chkaddress'];
// echo $name."<br>".$email."<br>".$address;
      if(mysqli_query($conn, "INSERT INTO `orderr` (`name`,`total_price`,`email`, `address`,`payment_type`,`added_on`,`order_status`) VALUES('$name','$Total','$email','$address','Cash on Delivery',NOW(),'0')")) {
        $ord_id    =   mysqli_insert_id($conn);
    while($cart_item = mysqli_fetch_assoc($ins))
                {
                   $prd_id    =   $cart_item['id'];
                   $prd_qty   =   $cart_item['qty'];
                   $prd_price =   $cart_item['tprice'].' ';
        $query = "INSERT INTO `order_detail`(`ord_id`, `prd_id`, `quantity`, `price`, `added_on`) VALUES ($ord_id,$prd_id,'$prd_qty','$prd_price',NOW())";
                   if(mysqli_query($conn,$query))
                    {
                      mysqli_query($conn, "TRUNCATE cart");
                       $msg = 'inserted';
                       $prd = mysqli_query($conn, "SELECT * FROM product WHERE `id` = $prd_id ");
                       $prd_item = mysqli_fetch_assoc($prd);
                       $new_qty = $prd_item['qty'];
                       $new_qty = (((int)$new_qty)-((int)$prd_qty));
                       mysqli_query($conn, "UPDATE `product` SET `qty`='$new_qty' WHERE `id` = $prd_id");
                       echo "<script>window.location.href = 'thankyou.php';</script>";
                    }
                  else
                  { echo 'error '.mysqli_error($conn);}
                                } 
            }

                                }
          ?>


  <!-- Bootstrap 5 JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
</body>
</html>